void print_buffer(const unsigned char *bufer,int lingth);
